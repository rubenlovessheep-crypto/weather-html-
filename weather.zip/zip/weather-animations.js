(() => {
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduceMotion || !Element.prototype.animate) return;

  const rise = (element, delay = 0) => {
    element.animate(
      [
        { opacity: 0, transform: "translateY(8px)" },
        { opacity: 1, transform: "translateY(0)" }
      ],
      { duration: 420, delay, easing: "cubic-bezier(.2, .7, .2, 1)" }
    );
  };

  const staggerChildren = (container) => {
    Array.from(container.children).forEach((child, index) => {
      rise(child, Math.min(index * 35, 420));
    });
  };

  const forecast = document.getElementById("forecast");
  const hourly = document.getElementById("hourly");
  const forecastObserver = new MutationObserver(() => staggerChildren(forecast));
  const hourlyObserver = new MutationObserver(() => staggerChildren(hourly));

  forecastObserver.observe(forecast, { childList: true });
  hourlyObserver.observe(hourly, { childList: true });

  const changingValues = [
    document.getElementById("temperature"),
    document.getElementById("current-icon"),
    document.getElementById("condition"),
    ...document.querySelectorAll(".metric-value")
  ];

  for (const element of changingValues) {
    const valueObserver = new MutationObserver(() => rise(element));
    valueObserver.observe(element, { childList: true, characterData: true, subtree: true });
  }
})();
